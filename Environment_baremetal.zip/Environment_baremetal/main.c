/*
 * Dummy main source file.
 *
 * Please add apropriate include file
 *
 */

int main(void) {
	unsigned int i = 0;
	while (1) {
		i ++;
	}
	return 0;
}
